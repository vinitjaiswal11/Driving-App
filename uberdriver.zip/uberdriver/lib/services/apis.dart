class Apis{
  static const String BASE_URL = "https://uber.thedigitalkranti.com/api/";
  static const String LOGIN_API = BASE_URL + "driver/login";
  static const String SIGNUP_API = BASE_URL + "driver/login/signup";
  static const String OTP_API = BASE_URL + "driver/login/verifyOTP";




}