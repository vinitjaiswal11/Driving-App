import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberdriver/color/AppColors.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';





class VehiclePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return VehiclePageLoader();
  }
}
class VehiclePageLoader extends State<VehiclePage>with SingleTickerProviderStateMixin
{

  bool expanded = true;
  AnimationController controller;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400),
      reverseDuration: Duration(milliseconds: 400),
    );
  }

  final ImagePicker _picker = ImagePicker();

  File _image;
  final picker = ImagePicker();

  Future getImagefromGallery() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  Future getImagefromCamera() async {
    final pickedFile = await picker.getImage(source: ImageSource.camera);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }
  void _modalBottomSheetMenu(){
    showModalBottomSheet(
        context: context,
        builder: (builder){
          return new Container(
            height: 150.0,
            color: Colors.transparent, //could change this to Color(0xFF737373),
            //so you don't have to change MaterialApp canvasColor
            child: Column(
              children: [
                ListTile(
                  leading: Icon(
                      Icons.image
                  ),
                  title: Text("Gallery"),
                  onTap: (){
                    Navigator.pop(context);
                    getImagefromGallery();
                  },
                ),
                ListTile(
                  leading: Icon(
                      Icons.camera_alt
                  ),
                  title: Text("Camera"),
                  onTap: (){
                    Navigator.pop(context);
                    getImagefromCamera();
                  },
                )
              ],
            ),
          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
        appBar: AppBar(
          backgroundColor: AppColors.black,
          title:
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  child: Text("UBER",style: TextStyle(
                      fontSize: 20,fontWeight: FontWeight.bold,
                      color: AppColors.white
                  )),
                ),
                Container(
                  width: 105,
                  height: 40,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: AppColors.white,
                      style: BorderStyle.solid,
                      width: 1.0,
                    ),
                    borderRadius: BorderRadius.all(Radius.circular(120)),
                    color: AppColors.white,

                    //color: Color(0xFFFff3f6c),
                  ),
                  child:
                  InkWell(
                    onTap: (){

                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding:EdgeInsets.only(left: 15),
                          child: Text("Help",style: TextStyle(color: AppColors.black,fontSize: 16),),
                        ),
                        // Container(
                        //   padding:EdgeInsets.only(right: 10),
                        //   child: Icon(Icons.keyboard_arrow_down),
                        // )
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 0, 10, 10),
                          child:
                          IconButton(
                              icon: AnimatedIcon(
                                icon: AnimatedIcons.menu_close,
                                progress: controller,
                                semanticLabel: 'Show menu',
                              ),
                              onPressed: () {
                                setState(() {
                                  expanded ? controller.forward() : controller.reverse();
                                  expanded = !expanded;
                                });
                              }),
                        )],
                    ),
                  ),

                )
              ],
            ),
          ),

          centerTitle: false,

          // Row(
          //   children: [
          //     Container(
          //       child: CircleAvatar(
          //         backgroundImage:AssetImage("assets/images/aa.png") ,
          //
          //       ),
          //     ),
          //     Container(
          //       padding: EdgeInsets.only(),
          //       decoration: BoxDecoration(
          //
          //           border: Border(
          //               left: BorderSide(
          //                 color: Colors.white,
          //
          //               )
          //           )
          //         // borderRadius:
          //         // BorderRadius.all(Radius.circular(4)),
          //       ),
          //       child: Text("MEN",style: TextStyle(
          //           fontWeight: FontWeight.w600,
          //           color: Colors.black87
          //       ),
          //
          //
          //       ),
          //     )
          //
          //   ],
          // ),




          iconTheme: IconThemeData(color: Colors.black),
          // pinned: true,
          //  floating: true,
          elevation: 1,
          automaticallyImplyLeading: false,

          actions: <Widget>[



            // IconButton(
            //   onPressed: () {
            //     // getCurrentLocation();
            //   },
            //   icon: Icon(
            //     Icons.my_location,
            //     color: Colors.white,
            //   ),
            // ),
            // IconButton(
            //   onPressed: () {
            //     // getCurrentLocation();
            //   },
            //   icon: Icon(
            //     Icons.notifications,
            //     color: Colors.black,
            //   ),
            // )
          ],
          // IconButton(
          //   onPressed: (){},
          //   icon: Icon(
          //     Icons.qr_code_outlined,
          //     color: Colors.white,
          //   ),
          // ),

          // IconButton(
          //   onPressed: ()async {
          //     //_BottomSheetMenu();
          //   },
          //
          //   icon: Icon(
          //       Icons.notifications,
          //       color: Colors.white
          //   ),
          // ),
          // IconButton(
          //   onPressed: (){
          //
          //
          //   },
          //   icon: Icon(
          //     Feather.help_circle,
          //     color: AppColors.white,
          //   ),
          // ),

        ),
        body: SingleChildScrollView(
          child: ListView(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            children: [
              Container(
                height: 80,
                color: AppColors.lightblue,
                padding: EdgeInsets.only(left: 15,
                    top: 10,right: 10),

                child:
                Column(
                  // mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(

                      child: Text("Account activation may be delayed",style: TextStyle(
                          color: AppColors.black,fontSize: 15,fontWeight: FontWeight.w600
                      ),),
                    ),
                    Container(
                      padding: EdgeInsets.only(top: 5),
                      child: Text("Due to COVID-19,processing documents is taking longer "
                          "than usual.Thanks for your patience",style: TextStyle(
                        color: AppColors.black,
                      ),),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 30,left: 10),
                child: Text("Take a photo of your  Vehicle Permit",style: TextStyle(
                    fontWeight: FontWeight.w600,fontSize: 18
                ),),
              ),
              Container(
                padding: EdgeInsets.only(top: 25,left: 10),
                child: Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing "
                    "software like Aldus PageMaker including versions of Lorem Ipsum.",style: TextStyle(
                    fontWeight: FontWeight.w300,fontSize: 14
                ),),
              ),
              // Container(
              //   padding: EdgeInsets.only(top: 20,left: 10),
              //   child: Text("1.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing "
              //       "software like Aldus PageMaker including versions of Lorem Ipsum. ",style: TextStyle(
              //       fontWeight: FontWeight.w400,fontSize: 14,color: AppColors.grayText
              //   ),),
              // ),
              Column(
                children: [
                  Container(
                    padding: EdgeInsets.all(22),
                    child: Center(
                      child: Container(




                        height: 200,
                        // width: 100,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(
                                color: Colors.black
                            ),
                            image: DecorationImage(
                                image: _image == null
                                    ? NetworkImage("https://affairscloud.com/assets/uploads/2020/02/Madhya-Pradesh-launches-unified-vehicle-registration-card.jpg")
                                    : FileImage(_image),
                                fit: BoxFit.cover
                            )
                        ),
                      ),
                    ),
                  ),
                ],
              ),












            ],
          ),
        ),

        bottomNavigationBar: Container(
          padding: EdgeInsets.only(
              bottom: 10,
              left: 10,
              right: 10
          ),
          child: Material(
            color: Color.fromRGBO(0, 0, 0, 1),
            borderRadius: BorderRadius.circular(0),
            child: InkWell(
              borderRadius: BorderRadius.circular(0),
              splashColor: Colors.blueAccent,
              onTap: ()async{
                _modalBottomSheetMenu();
              },
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(1),
                ),
                child: Center(
                  child:
                  Text(
                    // loading == true ? "Loading.." :
                    "Take photo",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight:FontWeight.w400,
                        fontSize: 18
                    ),
                  ),
                ),
              ),
            ),
          ),
        )


    );

  }


}