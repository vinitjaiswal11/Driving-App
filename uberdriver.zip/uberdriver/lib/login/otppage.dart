import 'dart:io';

import 'package:flutter/material.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';

import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:uberdriver/color/AppColors.dart';
import 'package:uberdriver/services/apis.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uberdriver/login/detailregister.dart';
import 'package:uberdriver/login/second.dart';
import 'package:uberdriver/login/third.dart';




class Otp extends StatelessWidget{
  final mobile,value;
  Otp(this.mobile,this.value);

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return OtpLoader(this.mobile,this.value);
  }

}
class   OtpLoader extends StatefulWidget {

  final mobile,value;
  OtpLoader(this.mobile,this.value);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return OtpView();
  }
}
class OtpView extends State<OtpLoader> {
  bool loading = false;
  bool ani = false;
  Color _color = Colors.black.withOpacity(0.3);
  bool fail;
  Future checkOtp(otp) async {
    try {
      var sp = await SharedPreferences.getInstance();
      setState(() {
        loading = true;
        ani = false;
        fail = false;
        _color = Colors.black.withOpacity(0.3);
      });
      var url = Apis.OTP_API;

      // var data = json.encode(map);
      var data = {
        "driver_id": widget.value,
        "otp": otp,
        "device_id": "12345789",
        "device_name": "1234578"
      };
      print(data.toString());
      //http.Response res = await http.post(url, body: data);
      var res = await apiPostRequest(url,data);
      print(res);
      setState(() {
        loading = false;
        var chekExist = json.decode(res)['status'];

       // sp.setString("token", json.decode(res)['accessToken']);
        if (chekExist == "1") {
          print("check 1");

          var firstname= json.decode(res)['driver_details']['first_name'];
          var lastname= json.decode(res)['driver_details']['last_name'];
          var fullname= json.decode(res)['driver_details']['full_name'];
          var email =   json.decode(res)['driver_details']['email'];
          var phone =   json.decode(res)['driver_details']['mobile'];
          if(firstname ==""||lastname ==""||email ==""||phone =="")
            {
              Navigator.push(context, MaterialPageRoute(builder: (context) => RegisterPage(firstname,lastname,email,phone) ));
            }
          else{
            Navigator.push(context, MaterialPageRoute(builder: (context) => DetailregisterPage() ));
          }






        }
      });
    }
    catch(e)
    {
      print("Network fail");

    }
    // var chekExist = json.decode(res.body)['isExists'];
    // print(chekExist);
  }
  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.OTP_API);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }





  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        // title: Text("Login"),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(
            color: Colors.black
        ),
      ),
      backgroundColor: Colors.white,



      body:
      SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Column(


                children: <Widget>

                [
                  // Container(
                  //   // padding: EdgeInsets.only(
                  //   //     top: 0
                  //   // ),
                  //   height: 200,
                  //   width: 200,
                  //   decoration: BoxDecoration(
                  //     borderRadius: BorderRadius.all(Radius.circular(10)),
                  //     image: DecorationImage(
                  //       image: AssetImage("assets/images/otp_sms.png"),
                  //       fit: BoxFit.fill,
                  //     ),
                  //   ),
                  //
                  // ),
                  Container(
                    padding: EdgeInsets.only(
                        top: 10,
                        bottom: 0,
                        right: 10,
                        left: 10

                    ),

                    child: Column(
                      children: [
                        Row(
                          // mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Padding(
                              padding: EdgeInsets.only(
                                  top: 5,
                                  bottom: 5,
                                  right: 10,
                                  left: 10

                              ),

                              child: Text(
                                "Enter the 4-digit code has been sent to:",
                                style: TextStyle(
                                    color : Colors.black,
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.normal
                                ),
                              ),
                            )
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [

                            Padding(
                              padding: EdgeInsets.only(
                                  top: 0,
                                  bottom: 0,
                                  right: 10,
                                  left: 10

                              ),

                              child: Text(
                                  widget.mobile,
                                style: TextStyle(
                                    color : AppColors.black,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.w600
                                ),
                              ),
                            )
                          ],
                        ),
                        // Row(
                        //   mainAxisAlignment: MainAxisAlignment.center,
                        //   children: [
                        //     Padding(
                        //       padding: EdgeInsets.only(
                        //           top: 15,
                        //           bottom: 5,
                        //           right: 10,
                        //           left: 10
                        //       ),
                        //
                        //       child: Text(
                        //         "ENTER OTP",
                        //         style: TextStyle(
                        //             color : Colors.black.withOpacity(0.6),
                        //             fontSize: 25.0,
                        //             fontWeight: FontWeight.bold
                        //         ),
                        //       ),
                        //     )
                        //   ],
                        // ),
                      ],
                    ),
                  ),

                  Container(
//                     padding: EdgeInsets.only(right: 190),
                    padding: EdgeInsets.only(
                        left: 15,
                        top: 20
                    ),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width/2,
                        child: OTPTextField(
                          // onChanged:(val){
                          //   setState(() {
                          //      otp = val.toString();
                          //   });
                          // },
                          length: 4,
                          width: MediaQuery.of(context).size.width,
                          textFieldAlignment: MainAxisAlignment.spaceAround,
                          fieldWidth: 40,

                          fieldStyle: FieldStyle.underline,


                          style: TextStyle(
                              fontSize: 17
                          ),
                          onCompleted: (pin) {
                             checkOtp(pin);
                          },
                        ),
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            top: 15,
                            bottom: 5,
                            right: 10,
                            left: 20
                        ),

                        child: Text(
                          "Resend code in 00.10",
                          style: TextStyle(
                              color : AppColors.grayText,
                              fontSize: 15.0,
                              fontWeight: FontWeight.w500
                          ),textAlign: TextAlign.start,
                        ),
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(
                            top: 15,
                            bottom: 5,
                            right: 10,
                            left: 20
                        ),

                        child:
                        InkWell(onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage() ));
                        },
                          child: Container(
                            padding: EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: AppColors.black,
                                style: BorderStyle.solid,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(120)),
                              color: AppColors.black,

                              //color: Color(0xFFFff3f6c),
                            ),

                            child: Text(
                              "Use Password",
                              style: TextStyle(
                                  color : AppColors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w500
                              ),textAlign: TextAlign.start,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),


                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}