import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberdriver/color/AppColors.dart';
import 'package:uberdriver/login/third.dart';
import 'package:uberdriver/services/apis.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:uberdriver/login/detailregister.dart';



class RegisterPage extends StatefulWidget {
  final firstname,lastname,email,phone;
  RegisterPage(this.firstname,this.lastname,this.email,this.phone);
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return RegisterPageLoader();
  }
}

class RegisterPageLoader extends State<RegisterPage> {

  var mobile = TextEditingController();
  var firstnam = TextEditingController();
  var lastnam = TextEditingController();
  var email = TextEditingController();
  bool loading = false;
  bool ani = false;
  Color _color = Colors.black.withOpacity(0.3);
  bool fail;

  Future getSignup() async
  {
    try
    {
      var sp = await SharedPreferences.getInstance();
      setState(() {
        loading = true;
        ani = false;
        fail = false;
        _color = Colors.black.withOpacity(0.3);
      });

      var url = Apis.SIGNUP_API;
      // var data = json.encode(map);
      var data = {
        "mobile": widget.phone,
        "first_name": firstnam.text,
        "last_name":lastnam.text,
        "email": email.text,
      };
      print(data.toString());
      //http.Response res = await http.post(url, body: data);
      var res = await apiPostRequest(url,data);
      print(res);
      setState(() {
        loading = false;
      });
      var chekExist = json.decode(res)['status'];
      print(chekExist);
      if (chekExist == "1") {
        Navigator.push(context, MaterialPageRoute(builder: (context) => DetailregisterPage()));
      }
    }
    catch(e)
    {
      print("Network Fail");
    }
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.SIGNUP_API);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  getmobile() async{
    setState(() {
      mobile.text = widget.phone;
    });
  }

  @override
  void initState(){
    super.initState();
    getmobile();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.black,
        title: Text(
          "",
          style: TextStyle(color: AppColors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: ListView(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          children: [
            Container(
              height: 60,
              padding: EdgeInsets.only(left: 10,
              top: 10),
              color: AppColors.lightblue ,
              child: Text("Drive with Uber. Earn on your schedule",style: TextStyle(
                color: AppColors.black,fontSize: 15
              ),),
            ),
            Container(
              padding: EdgeInsets.only(top: 10,left: 10),

              child: ListTile(
                title: Text("Let's start with creating your",style: TextStyle(
                  fontSize: 25,//fontWeight: FontWeight.w600
                ),),
                subtitle: Text("account",style: TextStyle(
                  fontSize: 25,color: AppColors.black//fontWeight: FontWeight.w600
                ),),
              )
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(right: 0,top: 40,left: 0,bottom: 10),


                      child: SizedBox(
                        child: InkWell(
                          onTap: (){
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                          },

                          child:
                            ListTile(
                              title: Text("First Name"),
                              subtitle:
                              Card(
                                child: Container(
                                  padding: EdgeInsets.all(0.0),
                                  height: 40,
                                  width: 40,
                                  decoration:  BoxDecoration(
                                      // border: Border.all(
                                      //  // color: AppColors.selectedItemColor,
                                      //   style: BorderStyle.solid,
                                      //   width: 1.0,
                                      // ),
                                      borderRadius: BorderRadius.all(Radius.circular(1)),
                                      color: AppColors.backColor,

                                  ),
                                  child: TextField(
                                    controller: firstnam,
                                    //controller: mobile,
                                    decoration: InputDecoration(
                                        border: InputBorder.none,

                                        //hintText: "Mobile Number",
                                        hintStyle: TextStyle(color: Colors.grey[400]
                                        ),
                                        contentPadding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        counterText: ""

                                    ),
                                  //  maxLength: 10,

                                  ),

                                ),
                              )
                            ),


                        ),
                      ),
                    ),
                  ),

                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(right: 0,top: 40,bottom: 10),


                      child: SizedBox(
                        child: InkWell(
                          onTap: (){
                           // Navigator.push(context, MaterialPageRoute(builder: (context)=>RegisterPage()));
                          },

                          child:
                          ListTile(
                              title: Text("Last Name"),
                              subtitle:
                              Card(
                                child: Container(
                                  padding: EdgeInsets.all(0.0),
                                  height: 40,
                                  width: 20,
                                  decoration:  BoxDecoration(
                                    // border: Border.all(
                                    //  // color: AppColors.selectedItemColor,
                                    //   style: BorderStyle.solid,
                                    //   width: 1.0,
                                    // ),
                                    borderRadius: BorderRadius.all(Radius.circular(1)),
                                    color: AppColors.backColor,

                                  ),
                                  child: TextField(
                                    controller: lastnam,
                                    //controller: mobile,
                                    decoration: InputDecoration(
                                        border: InputBorder.none,

                                        //hintText: "Mobile Number",
                                        hintStyle: TextStyle(color: Colors.grey[400]
                                        ),
                                        contentPadding: EdgeInsets.only(
                                          left: 10,
                                        ),
                                        counterText: ""

                                    ),
                                    //  maxLength: 10,

                                  ),

                                ),
                              )
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Email Address"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              controller: email,
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Phone Number"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              controller: mobile,
                              readOnly: true,
                              decoration: InputDecoration(
                                  border: InputBorder.none,


                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Password"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("City"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 0),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Invite code"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 0,left: 15,bottom: 20),
              child: Text("Optional",style: TextStyle(color: AppColors.grayBorder),),
            ),
            Container(
              padding: EdgeInsets.only(left: 15),
              child: RichText(
                text: new TextSpan(
                    text: "By proceeding.I agree to Uber's ",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 10,
                    ),
                    children: [
                      new TextSpan(
                          text: "Terms of Use ",
                          style: TextStyle(
                              color: AppColors.receiveColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 10
                          )
                      ),
                      new TextSpan(
                          text: "and acknowledge that I have read the ",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.normal,
                              fontSize: 10
                          )
                      ),
                      new TextSpan(
                          text: "Privacy Policy ",
                          style: TextStyle(
                              color: AppColors.receiveColor,
                              fontWeight: FontWeight.normal,
                              fontSize: 10
                          )
                      )
                    ]
                ),

              ),

            ),
            Container(
              padding: EdgeInsets.only(left: 15,top: 20),
              child: Text("I also agree that Uber or its representatives may contact me by email,phone"
                  ",or SMS(including by automated means) at the email address or number i provide,"
                  "including for marketing purposes",style: TextStyle(
                fontSize: 11
              ),


              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 10,top: 40,left: 10,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      getSignup();
                       //Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
                    },

                    child: Container(

                      height: 45,
                      // width: 20,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: AppColors.selectedItemColor,
                            style: BorderStyle.solid,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          color: AppColors.selectedItemColor
                      ),


                      child: Center(
                        child: Text(
                          loading == true ? "Loading.." :"Continue",style: TextStyle(
                            color : Colors.white,
                            fontSize: 19.0,
                            fontWeight: FontWeight.w400
                        ),

                        ),
                      ),
                    ),
                  ),
                ),
              ),

            ),
            Container(
              padding: EdgeInsets.only(top: 10,left: 15,bottom: 15),
              child: Text("This opportunity is for an independent contractor.Money made may vary "
                  "depending on number of trips taken,time of day,location,and other factors",
                style: TextStyle(
                    fontSize: 11
                ),),
            )
          ],
        ),
      ),


    );

  }


}