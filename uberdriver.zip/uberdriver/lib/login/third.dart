import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberdriver/color/AppColors.dart';
import 'package:uberdriver/login/detailregister.dart';


class LoginPage extends StatefulWidget {


  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LoginPageLoader();
  }
}

class LoginPageLoader extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.black,
        title: Text(
          "",
          style: TextStyle(color: AppColors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: ListView(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          children: [
            Container(
              //height: 60,
              padding: EdgeInsets.only(left: 20,
                  top: 20),

              child: Text("Please sign in",style: TextStyle(
                  color: AppColors.black,fontSize: 35
              ),),
            ),


            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Phone Number"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),
            Container(
              child: Container(
                padding: EdgeInsets.only(right: 0,top: 20,left: 0,bottom: 10),


                child: SizedBox(
                  child: InkWell(
                    onTap: (){
                      // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                    },

                    child:
                    ListTile(
                        title: Text("Password"),
                        subtitle:
                        Card(
                          child: Container(
                            padding: EdgeInsets.all(0.0),
                            height: 40,
                            width: 40,
                            decoration:  BoxDecoration(
                              // border: Border.all(
                              //  // color: AppColors.selectedItemColor,
                              //   style: BorderStyle.solid,
                              //   width: 1.0,
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(1)),
                              color: AppColors.backColor,

                            ),
                            child: TextField(
                              //controller: mobile,
                              decoration: InputDecoration(
                                  border: InputBorder.none,

                                  //hintText: "Mobile Number",
                                  hintStyle: TextStyle(color: Colors.grey[400]
                                  ),
                                  contentPadding: EdgeInsets.only(
                                    left: 10,
                                  ),
                                  counterText: ""

                              ),
                              //  maxLength: 10,

                            ),

                          ),
                        )
                    ),


                  ),
                ),
              ),
            ),

            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(right: 10,top: 60,left: 1,bottom: 10),


                      child: SizedBox(
                        child: InkWell(
                          onTap: (){
                            // Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                          },

                          child: Container(

                            height: 50,
                            // width: 20,
                            // decoration: BoxDecoration(
                            //     border: Border.all(
                            //       color: AppColors.selectedItemColor,
                            //       style: BorderStyle.solid,
                            //       width: 1.0,
                            //     ),
                            //     borderRadius: BorderRadius.all(Radius.circular(1)),
                            //     color: AppColors.selectedItemColor
                            // ),


                            child: Center(
                              child: Text(
                                "I forgot my password",style: TextStyle(
                                  color : AppColors.selectedItemColor,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.w400
                              ),

                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),

                  Expanded(
                    child: Container(
                      padding: EdgeInsets.only(right: 30,top: 40,bottom: 10,left: 100),


                      child: SizedBox(

                        child: InkWell(
                          onTap: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>DetailregisterPage()));
                          },

                          child: Container(


                            height: 50,

                             width: 20,
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: AppColors.selectedItemColor,
                                style: BorderStyle.solid,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(120)),
                              color: AppColors.selectedItemColor,

                              //color: Color(0xFFFff3f6c),
                            ),


                            child: Center(
                              child: Icon(Icons.arrow_forward,color: AppColors.white,

                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),

          ],
        ),
      ),


    );

  }


}