import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:uberdriver/login/otppage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uberdriver/services/apis.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:uberdriver/login/otppage.dart';
import 'package:uberdriver/login/second.dart';

class Login extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return LoginLoader();
  }
}

class LoginLoader extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LoginView();
  }
}

class LoginView extends State<LoginLoader> {
  alertDailog(text) async{
    showDialog(
        context: context,
        builder:(context){
          return AlertDialog(
            title: Text("Alert"),
            content: Text(text),
            actions: [
              FloatingActionButton(
                onPressed: (){
                  Navigator.pop(context);
                },
                child: Text("Ok"),
              )
            ],
          );
        }
    );
  }
  var mobile = TextEditingController();
  var id=TextEditingController();

  bool loading = false;
  bool ani = false;
  Color _color = Colors.black.withOpacity(0.3);
  bool fail;
  Future getLogin() async {
    try {
      var sp = await SharedPreferences.getInstance();
      setState(() {
        loading = true;
        ani = false;
        fail = false;
        _color = Colors.black.withOpacity(0.3);
      });

      var url = Apis.LOGIN_API;
      var map = Map<String, dynamic>();

     map['mobile'] = mobile.text;
      // var data = json.encode(map);
      var data = {"mobile": mobile.text};
      print(data.toString());
     // const headers = {'Content-Type': 'application/json'};
     // http.Response res = await http.post(url,body: data);
      var res = await apiPostRequest(url,data);

      print(res);
       setState(() {
        loading = false;
      });
      var chekExist = int.parse(json.decode(res)['status']);
       print(chekExist);
      if (chekExist > 0) {
         Navigator.push(context, MaterialPageRoute(builder: (context) => Otp(mobile.text,json.decode(res)['driver_id']) ));
      }
     }

     catch (e)
     {
       print("Network Fail");
     }
  }

  Future<String> apiPostRequest(String url, data) async {
    HttpClient httpClient = new HttpClient();
    HttpClientRequest request = await httpClient.postUrl(Uri.parse(url));
    request.headers.set('content-type', 'application/json');
    request.headers.set('api-key' , Apis.LOGIN_API);
    request.add(utf8.encode(json.encode(data)));
    HttpClientResponse response = await request.close();
    // todo - you should check the response.statusCode
    String reply = await response.transform(utf8.decoder).join();
    httpClient.close();
    return reply;
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        // title: Text("Login"),
        elevation: 0,
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      backgroundColor: Colors.white,
      body: Container(
        child: Column(
          children: <Widget>[
            Container(
              padding:
                  EdgeInsets.only(top: 10, bottom: 10, right: 10, left: 10),
              child: Row(
                children: [
                  Flexible(
                    child: Padding(
                      padding: EdgeInsets.only(
                          top: 5, bottom: 5, right: 10, left: 10),
                      child: Text(
                        "Login with your mobile number",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 30.0,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            Container(
//              height: 80,
              decoration: BoxDecoration(
                  // image: DecorationImage(
                  //     image:AssetImage(''),
                  //   fit: BoxFit.fill
                  // )

                  ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 0, left: 20, right: 20),
              child: Column(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: <Widget>[
                        Container(
                          padding: EdgeInsets.all(3.0),
//                          decoration: BoxDecoration(
//                              border: Border(bottom: BorderSide(color: Colors.grey[400]))
//                          ),
                          child: TextField(
                            controller: mobile,
                            //controller: mobile,
                            autofocus: true,
                            decoration: InputDecoration(
                              prefix: Text(
                                "+91 ",
                                style: TextStyle(
                                    color: Colors.black, fontSize: 20),
                              ),
//                                border: InputBorder.none,

                              hintText: "Mobile Number",
                              hintStyle: TextStyle(color: Colors.grey[400]),
                              contentPadding: EdgeInsets.only(
                                left: 10,
                              ),
                              counterText: "",
                            ),
                            maxLength: 10,
                            keyboardType: TextInputType.number,
                            style: TextStyle(fontSize: 20),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Container(
                    padding: EdgeInsets.only(
                        left: 10, right: 10, top: 10, bottom: 10),
                    color: Colors.blueAccent.withOpacity(0.1),
                    child: Text(
                      "Your mobile number will be use for all ride related communication. You should receive an SMS with code for verification.",
                      style: TextStyle(
                          fontSize: 12, color: Colors.black.withOpacity(0.6)),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
      bottomNavigationBar: Container(
        padding: EdgeInsets.only(bottom: 20, left: 20, right: 20),
        child: Material(
          color: Color.fromRGBO(0, 0, 0, 1),
          borderRadius: BorderRadius.circular(120),
          child: InkWell(
            borderRadius: BorderRadius.circular(120),
            splashColor: Colors.blueAccent,
            onTap: () {
              if (mobile.text.length == 10) {
                getLogin();
              } else {
                alertDailog("please enter number");
              }
              // Navigator.push(context, MaterialPageRoute(builder: (context)=>OtpLoader()));
            },
            child: Container(
              height: 45,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(120),
              ),
              child: Center(
                child: Text(
                   loading == true ? "Loading.." :
                  "Login",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w400,
                      fontSize: 20),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
