

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberdriver/color/AppColors.dart';
import 'package:uberdriver/login/second.dart';
import 'package:uberdriver/login/loginpage.dart';
import 'package:flutter_icons/flutter_icons.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return HomepageLoader();
  }
}

class HomepageLoader extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Stack(
        children: [
          SingleChildScrollView(
            child: ListView(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              children: [
                Container(
                  height: 458,
                    child: Image(
                  image: AssetImage("assets/images/aaa.png"),
                )),
                Container(
                  padding: EdgeInsets.only(top: 20,left: 5,bottom: 0),

                    child:ListTile(
                      title:  Text("Welcome to the",
                        style: TextStyle(color: AppColors.black,fontSize: 30),
                      ),
                      subtitle: Text("Driver app",style: TextStyle(color: AppColors.black,fontSize: 30),),
                    )



                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.only(right: 10,top: 40,left: 10,bottom: 10),


                          child: SizedBox(
                            child: InkWell(
                              onTap: (){
                                 Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginLoader()));
                              },

                              child: Container(

                                height: 50,
                                // width: 20,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                      color: AppColors.black,
                                      style: BorderStyle.solid,
                                      width: 1.0,
                                    ),
                                  borderRadius: BorderRadius.all(Radius.circular(120)),
                                  color: AppColors.black
                                ),


                                child: Center(
                                  child: Text(
                                    "SIGN IN",style: TextStyle(
                                      color : Colors.white,
                                      fontSize: 19.0,
                                      fontWeight: FontWeight.w400
                                  ),

                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      // Expanded(
                      //   child: Container(
                      //     padding: EdgeInsets.only(right: 10,top: 40,bottom: 10),
                      //
                      //
                      //     child: SizedBox(
                      //       child: InkWell(
                      //         onTap: (){
                      //           //Navigator.push(context, MaterialPageRoute(builder: (context)=>RegisterPage()));
                      //         },
                      //
                      //         child: Container(
                      //
                      //           height: 50,
                      //          // width: 20,
                      //           decoration: BoxDecoration(
                      //             border: Border.all(
                      //               color: AppColors.selectedItemColor,
                      //               style: BorderStyle.solid,
                      //               width: 1.0,
                      //             ),
                      //             borderRadius: BorderRadius.all(Radius.circular(1)),
                      //
                      //             //color: Color(0xFFFff3f6c),
                      //           ),
                      //
                      //
                      //           child: Center(
                      //             child: Text(
                      //               "REGISTER",style: TextStyle(
                      //                 color : AppColors.selectedItemColor,
                      //                 fontSize: 18.0,
                      //                 fontWeight: FontWeight.w400
                      //             ),
                      //
                      //             ),
                      //           ),
                      //         ),
                      //       ),
                      //     ),
                      //   ),
                      // )
                    ],
                  ),
                ),
                Container(
                  height: 1,
                  color: AppColors.toggele,
                ),
                Container(
                  padding: EdgeInsets.only(top: 20,left: 10),
                  child:
                  InkWell(
                    onTap:(){
                      launch("https://play.google.com/store/apps/details?id=com.kiranamart.newapp");

                    },
                    child: Text("Or Ride with Uber",style: TextStyle(
                      color: AppColors.selectedItemColor,fontSize: 18
                    ),),
                  ),
                )

              ],
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              // height: 10,
              child: AppBar(
                automaticallyImplyLeading: false,
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                        padding: EdgeInsets.only(top: 6, left: 2),
                        decoration: BoxDecoration(
                            //  color : Colors.black,
                            borderRadius: BorderRadius.all(Radius.circular(2))),
                        child: InkWell(
                            onTap: () {},
                            child: Text(
                              "Uber",
                              style: TextStyle(
                                  color: AppColors.white, fontSize: 25),
                            ))),
                    Container(
                      // color: Colors.black,
                      width: MediaQuery.of(context).size.width / 2.9,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [],
                      ),
                    )
                  ],
                ),
                elevation: 0,
                backgroundColor: Colors.transparent,
                iconTheme: IconThemeData(color: Colors.white),
                // actions: [
                //
                // ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget Mainpage() {
    return Container(
      child: Column(
        children: [
          Container(
              child: Expanded(
           // flex: 2,
            child:
                Text("Welcome to the Driver app",
                style: TextStyle(color: AppColors.black),),
          ))
        ],
      ),
    );
  }
}
