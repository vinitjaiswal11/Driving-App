import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:uberdriver/color/AppColors.dart';
import 'package:uberdriver/verify/driving.dart';
import 'package:uberdriver/verify/pancard.dart';
import 'package:uberdriver/verify/profile.dart';
import 'package:uberdriver/verify/vehicleinsurance.dart';
import 'package:uberdriver/verify/registration.dart';
import 'package:uberdriver/verify/vehiclepermit.dart';


class DetailregisterPage extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return DetailregisterPageLoader();
  }
}
class DetailregisterPageLoader extends State<DetailregisterPage>with SingleTickerProviderStateMixin
{

  bool expanded = true;
  AnimationController controller;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400),
      reverseDuration: Duration(milliseconds: 400),
    );
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.black,
        title:
        Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                child: Text("UBER",style: TextStyle(
                    fontSize: 20,fontWeight: FontWeight.bold,
                    color: AppColors.white
                )),
              ),
              Container(
                width: 105,
                height: 40,
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColors.white,
                    style: BorderStyle.solid,
                    width: 1.0,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(120)),
                  color: AppColors.white,

                  //color: Color(0xFFFff3f6c),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding:EdgeInsets.only(left: 15),
                      child: Text("Help",style: TextStyle(color: AppColors.black,fontSize: 16),),
                    ),
                    // Container(
                    //   padding:EdgeInsets.only(right: 10),
                    //   child: Icon(Icons.keyboard_arrow_down),
                    // )
                    Container(
                        padding: EdgeInsets.fromLTRB(0, 0, 10, 10),
                        child:
                        IconButton(
                            icon: AnimatedIcon(
                              icon: AnimatedIcons.menu_close,
                              progress: controller,
                              semanticLabel: 'Show menu',
                            ),
                            onPressed: () {
                              setState(() {
                                expanded ? controller.forward() : controller.reverse();
                                expanded = !expanded;
                              });
                            }),
                    )],
                ),

              )
            ],
          ),
        ),

        centerTitle: false,

        // Row(
        //   children: [
        //     Container(
        //       child: CircleAvatar(
        //         backgroundImage:AssetImage("assets/images/aa.png") ,
        //
        //       ),
        //     ),
        //     Container(
        //       padding: EdgeInsets.only(),
        //       decoration: BoxDecoration(
        //
        //           border: Border(
        //               left: BorderSide(
        //                 color: Colors.white,
        //
        //               )
        //           )
        //         // borderRadius:
        //         // BorderRadius.all(Radius.circular(4)),
        //       ),
        //       child: Text("MEN",style: TextStyle(
        //           fontWeight: FontWeight.w600,
        //           color: Colors.black87
        //       ),
        //
        //
        //       ),
        //     )
        //
        //   ],
        // ),




        iconTheme: IconThemeData(color: Colors.black),
        // pinned: true,
        //  floating: true,
        elevation: 1,
        automaticallyImplyLeading: false,

        actions: <Widget>[



          // IconButton(
          //   onPressed: () {
          //     // getCurrentLocation();
          //   },
          //   icon: Icon(
          //     Icons.my_location,
          //     color: Colors.white,
          //   ),
          // ),
          // IconButton(
          //   onPressed: () {
          //     // getCurrentLocation();
          //   },
          //   icon: Icon(
          //     Icons.notifications,
          //     color: Colors.black,
          //   ),
          // )
        ],
        // IconButton(
        //   onPressed: (){},
        //   icon: Icon(
        //     Icons.qr_code_outlined,
        //     color: Colors.white,
        //   ),
        // ),

        // IconButton(
        //   onPressed: ()async {
        //     //_BottomSheetMenu();
        //   },
        //
        //   icon: Icon(
        //       Icons.notifications,
        //       color: Colors.white
        //   ),
        // ),
        // IconButton(
        //   onPressed: (){
        //
        //
        //   },
        //   icon: Icon(
        //     Feather.help_circle,
        //     color: AppColors.white,
        //   ),
        // ),

      ),
      body: SingleChildScrollView(
        child: ListView(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          children: [
            Container(
              height: 80,
              color: AppColors.lightblue,
              padding: EdgeInsets.only(left: 15,
                  top: 10,right: 10),

              child:
              Column(
               // mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(

                    child: Text("Account activation may be delayed",style: TextStyle(
                        color: AppColors.black,fontSize: 15,fontWeight: FontWeight.w600
                    ),),
                  ),
                  Container(
                    padding: EdgeInsets.only(top: 5),
                    child: Text("Due to COVID-19,processing documents is taking longer "
                        "than usual.Thanks for your patience",style: TextStyle(
                        color: AppColors.black,
                    ),),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 30,left: 10),
              child: Text("Welcome back, Sonu",style: TextStyle(
                fontWeight: FontWeight.w600,fontSize: 25
              ),),
            ),
            Container(
              padding: EdgeInsets.only(top: 25,left: 10),
              child: Text("Required steps",style: TextStyle(
                  fontWeight: FontWeight.w600,fontSize: 18
              ),),
            ),
            Container(
              padding: EdgeInsets.only(top: 20,left: 10),
              child: Text("Here's what you need to do to set up your account.",style: TextStyle(
                  fontWeight: FontWeight.w600,fontSize: 16,color: AppColors.grayText
              ),),
            ),
            // Container(
            //   padding: EdgeInsets.only(top: 10),
            //   child: ListTile(
            //     title: Text("Driving License-Front",style: TextStyle(
            //       fontSize: 20,fontWeight: FontWeight.w600,
            //     ),),
            //     subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
            //     leading: Icon(Icons.article_rounded,color: AppColors.black,),
            //     trailing: Icon(Icons.chevron_right),
            //   ),
            // )
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell
                (
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>DrivingPage()));

                },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                        left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: AppColors.grayText
                            )
                          )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "Driving License-Front",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell(onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>PancardPage()));
              },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                          left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    color: AppColors.grayText
                                )
                            )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "PAN Card",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>ProfilePage()));
                },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                          left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    color: AppColors.grayText
                                )
                            )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "Profile Photo",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>VehiclePageins()));
                },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                          left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    color: AppColors.grayText
                                )
                            )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "Vehicle Insurance",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell(onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>RegistrationPage()));
              },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                          left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    color: AppColors.grayText
                                )
                            )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "Registration Certificate(RC)",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child:
              InkWell(onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>VehiclePage()));
              },
                child: Stack(
                  children: [
                    Container(
                      padding: EdgeInsets.only(
                          left: 55
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    color: AppColors.grayText
                                )
                            )
                        ),
                        child: ListTile(
                          // contentPadding:
                          // EdgeInsets.only(
                          //     bottom: 15,
                          //     left: 65,
                          //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                          title: Text(
                            "Vehicle Permit",style: TextStyle(
                            fontSize: 20,fontWeight: FontWeight.w600,
                          ),),
                          subtitle: Text("Get Started",style: TextStyle(color: AppColors.grayText),),
                          trailing:Icon(Icons.chevron_right),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        width: 50,
                        height: 50,
                        child: Icon(Icons.article_rounded,color: AppColors.black,),
                        // Image(
                        //   image: NetworkImage(
                        //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                        // ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 15,left: 10),
              child: Text("Completed steps",style: TextStyle(
                fontWeight: FontWeight.w600,color: AppColors.black,fontSize: 18
              ),),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Stack(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        left: 55
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: AppColors.grayText
                              )
                          )
                      ),
                      child: ListTile(
                        // contentPadding:
                        // EdgeInsets.only(
                        //     bottom: 15,
                        //     left: 65,
                        //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                        title: Text(
                          "WhatsApp support",style: TextStyle(
                          fontSize: 20,fontWeight: FontWeight.w600,
                        ),),
                        subtitle: Text("Completed",style: TextStyle(color: AppColors.priceControl),),

                      ),
                    ),
                  ),
                  Positioned(
                    top: 20,
                    left: 15,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: AppColors.lightgreen,
                          style: BorderStyle.solid,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(120)),
                        color: AppColors.lightgreen,

                        //color: Color(0xFFFff3f6c),
                      ),
                      child: Icon(Icons.check,color: AppColors.white,size: 22,),
                      // Image(
                      //   image: NetworkImage(
                      //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                      // ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Stack(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        left: 55
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: AppColors.grayText
                              )
                          )
                      ),
                      child: ListTile(
                        // contentPadding:
                        // EdgeInsets.only(
                        //     bottom: 15,
                        //     left: 65,
                        //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                        title: Text(
                          "Legal Agreements",style: TextStyle(
                          fontSize: 20,fontWeight: FontWeight.w600,
                        ),),
                        subtitle: Text("Completed",style: TextStyle(color: AppColors.priceControl),),

                      ),
                    ),
                  ),
                  Positioned(
                    top: 20,
                    left: 15,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: AppColors.lightgreen,
                          style: BorderStyle.solid,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(120)),
                        color: AppColors.lightgreen,

                        //color: Color(0xFFFff3f6c),
                      ),
                      child: Icon(Icons.check,color: AppColors.white,size: 22,),
                      // Image(
                      //   image: NetworkImage(
                      //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                      // ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.only(top: 10),
              child: Stack(
                children: [
                  Container(
                    padding: EdgeInsets.only(
                        left: 55
                    ),
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border(
                              bottom: BorderSide(
                                  color: AppColors.grayText
                              )
                          )
                      ),
                      child: ListTile(
                        // contentPadding:
                        // EdgeInsets.only(
                        //     bottom: 15,
                        //     left: 65,
                        //     right: 20),








//                                                leading: Image(
//                                                  image: NetworkImage("https://icons-for-free.com/iconfiles/png/512/automobile+car+sedan+transport+transportation+vehicle+icon-1320086843185925654.png"),
//                                                ),
                        title: Text(
                          "Preferred Language",style: TextStyle(
                          fontSize: 20,fontWeight: FontWeight.w600,
                        ),),
                        subtitle: Text("Completed",style: TextStyle(color: AppColors.priceControl),),

                      ),
                    ),
                  ),
                  Positioned(
                    top: 15,
                    left: 20,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: AppColors.lightgreen,
                          style: BorderStyle.solid,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(120)),
                        color: AppColors.lightgreen,

                        //color: Color(0xFFFff3f6c),
                      ),
                      child: Icon(Icons.check,color: AppColors.white,size: 22,),
                      // Image(
                      //   image: NetworkImage(
                      //       "https://www.uber-assets.com/image/upload/f_auto,q_auto:eco,c_fill,w_956,h_537/v1568070387/assets/b5/0a5191-836e-42bf-ad5d-6cb3100ec425/original/UberX.png"),
                      // ),
                    ),
                  ),
                ],
              ),
            ),









          ],
        ),
      ),


    );

  }


}